# Security Policy

## Supported Versions

Currently, the project is in a sealed state. We recommend always using the latest version tagged in releases.

## Reporting a Vulnerability

If you discover a vulnerability, please create a private issue on GitHub or reach out directly to the maintainers. Do not disclose security issues publicly until a patch is released.
